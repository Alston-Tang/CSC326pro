CS559 - Example Code, Utilities Directory

October 2008

This directory gathers up sample code that is useful for CS559
Projects. The files here are used in several example projects and
project platforms. 

Like most of the CS559 example code, this code is generally very
simplistic, and designed to be easy to give to students - its not
necessarily exemplary software engineering.

Many of the files here have evolved from earlier editions of the
sample code. In October 2008, I finally decided to start collecting
them in their own CVS module. 

$Header: /p/course/cs559-gleicher/private/CVS/Utilities/ReadMe-Utilities.txt,v 1.2 2008/10/13 19:21:22 gleicher Exp $
